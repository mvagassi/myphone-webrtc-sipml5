/** @namespace */
var mxn = {};

(function(){ 
    /** @exports Map as mxn.Map */
    var Map =
        /** @constructor */
        mxn.Map = function() {
        };
    
    /** A method. */
    Map.prototype.doThings = function() {
    };
})();